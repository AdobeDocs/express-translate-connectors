# Translate Connector Compatibility Service

A starter template for building a Translation connector for Adobe Express. This is a backend-only integration that connects Adobe Express to your translation service.

**Important**: Do not modify the structure or action names in `app.config.yaml` for the required actions (`locales`, and `translate`).

## Prerequisites

Before you begin, make sure you have an App Builder project in Adobe Developer Console:

1. Go to https://developer.adobe.com/console
2. Select your organization.
3. Click "Create new project" > "Project from template" > "App Builder".
4. Give it a name and save.
5. In the left sidebar, open a workspace (Stage or Production).

## Getting Started

1. **Install dependencies**:

    ```bash
    npm install
    ```

2. **Configure Locales**:
   Update the `SUPPORTED_LOCALES` array in `src/actions/locales.ts` with the languages your service supports.

3. **Implement Translation**:
   Replace the mock translation logic in `src/actions/translation.ts` with your actual translation service API calls.

4. **Configure Health Endpoint**:
   Update `src/actions/health.ts` to verify connectivity and status of your translation service.

5. **Add Credentials**:
   Add any required API keys to your `.env` file.

## Available Commands

- `aio app use` - To generate app builder config files
- `aio app dev` - Run locally for development
- `aio app test` - Run unit tests
- `aio app deploy` - Deploy to Adobe I/O Runtime
- `aio app undeploy` - Remove the deployment

## Project Structure

- `src/actions/locales.ts` - Returns supported languages (Required)
- `src/actions/translation.ts` - Handles the translation requests (Required)
- `src/actions/health.ts` - Health check endpoint for monitoring (Optional)
- `src/actions/tone.ts` - Handles tone-specific translations (Optional)
- `src/actions/feedback.ts` - Handles user feedback on translations (Optional)

### Optional Actions

The `health`, `tone` and `feedback` actions are entirely optional. If your translation service does not support these features, you can safely remove them:

1. Delete `src/actions/health.ts` and/or `src/actions/tone.ts` and/or `src/actions/feedback.ts`.
2. Remove their corresponding action definitions (`health`, `tone` and `feedback`) from `app.config.yaml`.
