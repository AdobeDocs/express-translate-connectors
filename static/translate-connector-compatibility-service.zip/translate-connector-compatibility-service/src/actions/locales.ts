/*************************************************************************
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 **************************************************************************/

import { LocalesResponse, Locale } from "../types/translate-connector-sdk";
import { ActionResponse } from "../types";

type LocalesActionResponse = ActionResponse<LocalesResponse>;

const SUPPORTED_LOCALES: Locale[] = [
    { code: "en-US", label: "English" },
    { code: "fr-FR", label: "French" },
    { code: "de-DE", label: "German" },
    { code: "it-IT", label: "Italian" },
    { code: "es-ES", label: "Spanish (Spain)" },
    { code: "th-TH", label: "Thai" }
];

export async function main(): Promise<LocalesActionResponse> {
    console.log("Locales requested");
    // Add supported locales logic here
    const response: LocalesActionResponse = {
        statusCode: 200,
        body: { locales: SUPPORTED_LOCALES }
    };
    return response;
}
