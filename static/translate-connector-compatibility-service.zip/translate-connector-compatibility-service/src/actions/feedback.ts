/*************************************************************************
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 **************************************************************************/

import {
    FeedbackRequest,
    FeedbackResponse,
    ErrorCode,
    FeedbackType,
    FeedbackPositiveReason,
    FeedbackNegativeReason
} from "../types/translate-connector-sdk";
import { ActionParams, ActionResponse } from "../types";

type FeedbackActionResponse = ActionResponse<FeedbackResponse>;

export async function main(params: ActionParams): Promise<FeedbackActionResponse> {
    const { type, reason, note } = params as unknown as FeedbackRequest;

    const validTypes = Object.values(FeedbackType);
    const validReasons = [...Object.values(FeedbackPositiveReason), ...Object.values(FeedbackNegativeReason)];
    console.log("Feedback called with parameters:", { type, reason, note });
    
    // Validate the required parameters
    if (!validTypes.includes(type) || !reason || !validReasons.includes(reason)) {
        const errorResponse: FeedbackActionResponse = {
            statusCode: 400,
            body: {
                errorCode: ErrorCode.BAD_REQUEST,
                errorMessage: "Missing required parameters"
            }
        };
        return errorResponse;
    }

    // Add logic to handle feedback - for example storing it in a database or sending it to an analytics service
    const successResponse: FeedbackActionResponse = {
        statusCode: 200,
        body: {}
    };
    return successResponse;
}
