/*************************************************************************
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 **************************************************************************/

import { TranslationResponse, TranslationRequest, ErrorCode } from "../types/translate-connector-sdk";
import { ActionParams, ActionResponse } from "../types";
import { verifyAuth } from "./auth";

type TranslationActionResponse = ActionResponse<TranslationResponse>;

export async function main(params: ActionParams): Promise<TranslationActionResponse> {
    // Require a valid OAuth access token before performing any work.
    const auth = await verifyAuth(params);
    if (!auth.ok) {
        return {
            statusCode: auth.status,
            body: {
                errorCode: ErrorCode.UNAUTHORIZED,
                errorMessage: auth.message,
                result: []
            }
        };
    }

    const { sourceLocale, targetLocale, items } = params as unknown as TranslationRequest;

    console.log("Secured translation requested", { sub: auth.payload?.sub, sourceLocale, targetLocale, items });

    // Validate the required parameters
    if (!sourceLocale || !targetLocale || items.length === 0) {
        const errorResponse: TranslationActionResponse = {
            statusCode: 400,
            body: {
                errorCode: ErrorCode.BAD_REQUEST,
                errorMessage: "Missing required parameters",
                result: []
            }
        };
        return errorResponse;
    }

    // Add translation logic here
    const result: TranslationResponse["result"] = items.map((item: string) => `[${targetLocale}] ${item}`);

    const successResponse: TranslationActionResponse = {
        statusCode: 200,
        body: {
            result
        }
    };
    return successResponse;
}
