/*************************************************************************
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 **************************************************************************/

import { createRemoteJWKSet, jwtVerify, JWTPayload } from "jose";
import { ActionParams } from "../types";

/**
 * Result of validating the incoming Authorization header.
 */
export interface AuthResult {
    /** Whether the request carried a valid, verified access token. */
    ok: boolean;
    /** HTTP status to return when `ok` is false (401 unauthorized, 500 misconfiguration). */
    status: number;
    /** Human-readable reason, returned as `errorMessage` on failure. */
    message?: string;
    /** Verified JWT claims when `ok` is true. */
    payload?: JWTPayload;
}

// Cached per warm container so we do not refetch the JWKS on every invocation.
// `createRemoteJWKSet` internally caches keys and refetches only on an unknown key id.
let cachedJwks: ReturnType<typeof createRemoteJWKSet> | undefined;
let cachedJwksIssuer: string | undefined;

function getJwks(issuer: string): ReturnType<typeof createRemoteJWKSet> {
    if (cachedJwks === undefined || cachedJwksIssuer !== issuer) {
        const jwksUrl = new URL(".well-known/jwks.json", issuer.endsWith("/") ? issuer : `${issuer}/`);
        cachedJwks = createRemoteJWKSet(jwksUrl);
        cachedJwksIssuer = issuer;
    }
    return cachedJwks;
}

/**
 * Validates the `Authorization: Bearer <token>` header on the incoming request against the
 * configured OAuth 2.0 identity provider (Auth0). Verifies the token signature via the provider's
 * JWKS endpoint and checks the `iss` and `aud` claims and expiry.
 *
 * The provider is configured through action inputs (`app.config.yaml` -> `inputs`), which arrive on
 * `params`:
 * - `AUTH0_ISSUER`   e.g. `https://your-tenant.us.auth0.com/` (trailing slash matters, it must match `iss`)
 * - `AUTH0_AUDIENCE` e.g. `https://my-translate-connector-service` (the API identifier / token audience)
 */
export async function verifyAuth(params: ActionParams): Promise<AuthResult> {
    const issuer = params.AUTH0_ISSUER as string | undefined;
    const audience = params.AUTH0_AUDIENCE as string | undefined;

    if (!issuer || !audience) {
        return { ok: false, status: 500, message: "Auth is not configured (missing AUTH0_ISSUER or AUTH0_AUDIENCE)" };
    }

    const headers = params.__ow_headers as Record<string, string> | undefined;
    const authHeader = headers?.authorization;

    if (!authHeader || !authHeader.toLowerCase().startsWith("bearer ")) {
        return { ok: false, status: 401, message: "Missing or invalid Authorization header" };
    }

    const token = authHeader.slice("Bearer ".length).trim();

    try {
        const { payload } = await jwtVerify(token, getJwks(issuer), { issuer, audience });
        return { ok: true, status: 200, payload };
    } catch (error) {
        return { ok: false, status: 401, message: `Token validation failed: ${(error as Error).message}` };
    }
}
