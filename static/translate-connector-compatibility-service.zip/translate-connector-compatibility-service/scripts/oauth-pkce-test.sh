#!/usr/bin/env bash
#
# oauth-pkce-test.sh — End-to-end OAuth 2.0 Authorization Code + PKCE test
# for the Translate Connector, run entirely OUTSIDE Adobe Express.
#
# It mirrors exactly what Adobe Express does when a user clicks "Connect":
#   1. Generates a fresh PKCE code_verifier + S256 code_challenge.
#   2. Prints (and tries to open) the Auth0 /authorize URL.
#   3. You log in with a shared test account; the browser lands on the Adobe
#      redirect page with ?code=... in the address bar — paste that code back.
#   4. Exchanges the code at Auth0's /oauth/token endpoint (public client,
#      NO client_secret — this is PKCE).
#   5. Decodes the access token and prints its claims (iss / aud / exp).
#   6. Calls a protected connector endpoint with the Bearer token.
#
# A 200 in step 6 proves the whole chain: SPA app -> user login -> PKCE
# exchange -> JWT with correct aud/iss -> your action's token verification.
#
# Usage:
#   ./scripts/oauth-pkce-test.sh
#
# Any value below can be overridden via environment variable, e.g.:
#   TEST_ENDPOINT=".../translate-secure" ./scripts/oauth-pkce-test.sh
#
set -euo pipefail

# --- Config (override via env) ------------------------------------------------
AUTH0_DOMAIN="${AUTH0_DOMAIN:-express-devex-testing.us.auth0.com}"
CLIENT_ID="${CLIENT_ID:-ImGpPdzVbTNlilCFJGi7y3rGzY4491I0}"
AUDIENCE="${AUDIENCE:-https://my-translate-connector-service}"
SCOPE="${SCOPE:-openid profile offline_access}"
REDIRECT_URI="${REDIRECT_URI:-https://express.adobe.com/static/oauth-redirect.html}"
API_BASE="${API_BASE:-https://393012-187thistlelandfowl-stage.adobeioruntime.net/api/v1/web/translation}"
TEST_ENDPOINT="${TEST_ENDPOINT:-$API_BASE/locales-secure}"

# --- Dependency check ---------------------------------------------------------
for cmd in openssl curl python3; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "error: '$cmd' is required but not installed." >&2; exit 1; }
done

# base64url encode from stdin (no padding, URL-safe alphabet)
b64url() { openssl base64 -A | tr '+/' '-_' | tr -d '='; }

# URL-encode a single argument
urlenc() { python3 -c 'import sys,urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$1"; }

# --- 1. Generate PKCE pair ----------------------------------------------------
CODE_VERIFIER="$(openssl rand 32 | b64url)"
CODE_CHALLENGE="$(printf '%s' "$CODE_VERIFIER" | openssl dgst -binary -sha256 | b64url)"

# --- 2. Build the authorize URL ----------------------------------------------
AUTH_URL="https://${AUTH0_DOMAIN}/authorize?response_type=code"
AUTH_URL+="&client_id=$(urlenc "$CLIENT_ID")"
AUTH_URL+="&redirect_uri=$(urlenc "$REDIRECT_URI")"
AUTH_URL+="&scope=$(urlenc "$SCOPE")"
AUTH_URL+="&audience=$(urlenc "$AUDIENCE")"
AUTH_URL+="&code_challenge=${CODE_CHALLENGE}"
AUTH_URL+="&code_challenge_method=S256"

echo
echo "=== Step 1: Authorize ==="
echo "Open this URL and sign in with a shared test account:"
echo
echo "$AUTH_URL"
echo
# Best-effort: open in the default browser (macOS 'open', Linux 'xdg-open').
if command -v open >/dev/null 2>&1; then
  open "$AUTH_URL" >/dev/null 2>&1 || true
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$AUTH_URL" >/dev/null 2>&1 || true
fi

echo "After login you'll be redirected to:"
echo "  ${REDIRECT_URI}?code=XXXX&state=..."
echo "The page itself does nothing — copy the 'code' value from the address bar."
echo "(Authorization codes are single-use and expire in ~30-60s, so paste promptly.)"
echo
read -r -p "Paste the authorization code: " CODE
if [ -z "${CODE:-}" ]; then
  echo "error: no code provided." >&2
  exit 1
fi

# --- 3. Exchange the code for tokens (PKCE, no client_secret) -----------------
echo
echo "=== Step 2: Exchange code for tokens ==="
TOKEN_JSON="$(curl -sS "https://${AUTH0_DOMAIN}/oauth/token" \
  --data-urlencode 'grant_type=authorization_code' \
  --data-urlencode "client_id=${CLIENT_ID}" \
  --data-urlencode "code=${CODE}" \
  --data-urlencode "redirect_uri=${REDIRECT_URI}" \
  --data-urlencode "code_verifier=${CODE_VERIFIER}")"

ACCESS_TOKEN="$(printf '%s' "$TOKEN_JSON" | python3 -c 'import sys,json
try:
    print(json.load(sys.stdin).get("access_token",""))
except Exception:
    print("")')"

if [ -z "$ACCESS_TOKEN" ]; then
  echo "error: token exchange failed. Response:" >&2
  printf '%s\n' "$TOKEN_JSON" | python3 -m json.tool 2>/dev/null || printf '%s\n' "$TOKEN_JSON"
  exit 1
fi
echo "Access token received."

# --- 4. Decode and show the access token claims ------------------------------
echo
echo "=== Step 3: Access token claims ==="
printf '%s' "$ACCESS_TOKEN" | python3 -c 'import sys,json,base64
tok = sys.stdin.read().strip()
parts = tok.split(".")
if len(parts) < 2:
    print("Not a JWT (opaque token). Check that the audience is set correctly.")
    sys.exit(0)
p = parts[1]; p += "=" * (-len(p) % 4)
claims = json.loads(base64.urlsafe_b64decode(p))
print(json.dumps(claims, indent=2))
print()
print("iss:", claims.get("iss"))
print("aud:", claims.get("aud"))'

# --- 5. Call the protected endpoint with the token ---------------------------
echo
echo "=== Step 4: Call protected endpoint ==="
echo "GET ${TEST_ENDPOINT}"
HTTP_CODE="$(curl -sS -o /tmp/oauth-pkce-resp.txt -w '%{http_code}' \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" "$TEST_ENDPOINT")"
echo "HTTP ${HTTP_CODE}"
echo "Response body:"
cat /tmp/oauth-pkce-resp.txt; echo
rm -f /tmp/oauth-pkce-resp.txt

echo
if [ "$HTTP_CODE" = "200" ]; then
  echo "SUCCESS: full PKCE chain works end-to-end, independent of Adobe Express."
else
  echo "Endpoint returned HTTP ${HTTP_CODE}. If the token claims above look correct"
  echo "(iss + aud match your action's AUTH0_ISSUER / AUTH0_AUDIENCE), inspect the"
  echo "action logs with: aio app logs"
fi
