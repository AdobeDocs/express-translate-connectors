PROJECT:
https://developer.adobe.com/console/projects/393012/4566206088345693867/workspaces/4566206088345732119/details


Run from browser
https://393012-187thistlelandfowl-stage.adobeioruntime.net/api/v1/web/translation/locales

https://393012-187thistlelandfowl-stage.adobeioruntime.net/api/v1/web/translation/health

Run the following commands to test the translation service:

BASE="https://393012-187thistlelandfowl-stage.adobeioruntime.net/api/v1/web/translation"; echo "== health =="; curl -s "$BASE/health"; echo; echo "== locales =="; curl -s "$BASE/locales"; echo; echo "== translate =="; curl -s -X POST "$BASE/translate" -H "Content-Type: application/json" -d '{"sourceLocale":"en-US","targetLocale":"fr-FR","items":["Hello, world!"]}'; echo

BASE="https://393012-187thistlelandfowl-stage.adobeioruntime.net/api/v1/web/translation"; echo "== health =="; curl -s "$BASE/health"; echo; echo "== locales =="; curl -s "$BASE/locales"; echo;  echo "== tones =="; curl -s "$BASE/tones"; echo "== translate =="; curl -s -X POST "$BASE/translate" -H "Content-Type: application/json" -d '{"sourceLocale":"en-US","targetLocale":"fr-FR","items":["Hello, world!"]}'; echo

BASE="https://localhost:9080/api/v1/web/translation"; echo "== health =="; curl -s "$BASE/health"; echo; echo "== locales =="; curl -s "$BASE/locales"; echo;  echo "== tones =="; curl -s "$BASE/tones"; echo "== translate =="; curl -s -X POST "$BASE/translate" -H "Content-Type: application/json" -d '{"sourceLocale":"en-US","targetLocale":"fr-FR","items":["Hello, world!"]}'; echo