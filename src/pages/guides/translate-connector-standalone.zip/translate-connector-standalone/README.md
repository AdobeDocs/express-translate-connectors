# Translate Connector Starter

A self-contained starter template for building an [Adobe Express Translate Connector](https://developer.adobe.com/express/add-ons/docs/references/connectors/). No GitHub registry access or personal access token required — the SDK type definitions are bundled in the `types/` folder.

## Project Structure

```
translate-connector-standalone/
├── src/
│   └── server.ts       ← connector implementation — edit this file
├── types/
│   ├── translate-connector-sdk.d.ts   ← bundled SDK type definitions (do not edit)
│   ├── index.d.ts
│   └── package.json
├── package.json
├── tsconfig.json
└── README.md
```

## Prerequisites

-   **Node.js** &ge; 18.8.0

(No GitHub account or registry token needed).

## Getting Started

```bash
# Install dependencies
npm install

# Build and start the server (default port: 3000)
npm run serve
```

To run on a different port:

```bash
PORT=5000 npm run serve
```

## Implementing Your Connector

Open `src/server.ts` and replace the `TODO` comments in each method with calls to your actual translation service:

| Method | What to implement |
| --- | --- |
| `locales()` | Return the locales your service supports |
| `tones()` | Return supported tones, or `{ tones: [] }` if not applicable |
| `translate()` | Call your translation API and return translated strings in the same order as `request.items` |
| `health()` | Return `200` when your service is available |
| `feedback()` | Forward feedback to your analytics or quality pipeline (optional) |

## Endpoints

| Method | Endpoint     | Description              |
| ------ | ------------ | ------------------------ |
| `GET`  | `/health`    | Health check             |
| `GET`  | `/locales`   | Return supported locales |
| `GET`  | `/tones`     | Return supported tones   |
| `POST` | `/translate` | Translate content        |
| `POST` | `/feedback`  | Submit user feedback     |

## Try It Out

```bash
# Health check
curl http://localhost:3000/health

# List supported locales
curl http://localhost:3000/locales

# List supported locales with preferred language label translation
curl "http://localhost:3000/locales?preferredLanguage=fr-FR"

# List supported tones
curl http://localhost:3000/tones

# Translate text
curl -X POST http://localhost:3000/translate \
  -H "Content-Type: application/json" \
  -d '{
    "sourceLocale": "en-US",
    "targetLocale": "fr-FR",
    "items": ["Hello, world!", "Welcome to Adobe Express."],
    "tone": "formal"
  }'

# Translate text without a tone
curl -X POST http://localhost:3000/translate \
  -H "Content-Type: application/json" \
  -d '{
    "sourceLocale": "en-US",
    "targetLocale": "de-DE",
    "items": ["Create amazing designs."]
  }'

# Submit positive feedback
curl -X POST http://localhost:3000/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "type": "Positive",
    "reason": "AccurateTranslation"
  }'

# Submit negative feedback
curl -X POST http://localhost:3000/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "type": "Negative",
    "reason": "IncorrectTone",
    "note": "Translation felt too casual."
  }'
```

## About the Bundled Types

The `types/` folder contains the official `@adobe-ccwebext/ccweb-connector-sdk-types` TypeScript definitions. These give you full type safety and autocompletion in your editor without requiring registry access. The `package.json` `file:` dependency wires them up as if they were installed from npm — your `import type { ... } from "@adobe-ccwebext/ccweb-connector-sdk-types/translate"` statements work identically to the registry-based setup.

When Adobe publishes updated type definitions, you can replace `types/translate-connector-sdk.d.ts` with the latest version from the [Adobe Express developer documentation](https://developer.adobe.com/express/add-ons/docs/references/connectors/).

> **Note:** The connector APIs must be hosted over HTTPS with a valid SSL certificate for Adobe Express to be able to connect to them in production.
