import type {
    FeedbackRequest,
    FeedbackResponse,
    HealthResponse,
    LocalesResponse,
    TonesResponse,
    TranslationRequest,
    TranslationResponse
} from "@adobe-ccwebext/ccweb-connector-sdk-types/translate";
import express from "express";

/**
 * Starter implementation of an Adobe Express Translate Connector.
 *
 * Replace each method body with calls to your actual translation service API.
 * See https://developer.adobe.com/express/add-ons/docs/references/connectors/ for the full spec.
 */
class MyTranslateConnector {
    /**
     * Return the locales your translation service supports.
     * Use `preferredLanguage` to return locale labels in the user's language if your
     * service supports it (e.g. return "Español" instead of "Spanish" for es-* users).
     */
    locales(preferredLanguage?: string): LocalesResponse {
        console.log(`Preferred language: ${preferredLanguage ?? "not specified"}`);

        // TODO: replace with your service's supported locales
        return {
            locales: [
                { code: "en-US", label: "English (US)", category: "Popular languages" },
                { code: "es-ES", label: "Spanish (Spain)", category: "Popular languages" },
                { code: "fr-FR", label: "French", category: "Popular languages" },
                { code: "de-DE", label: "German", category: "Popular languages" },
                { code: "ja-JP", label: "Japanese", category: "Other languages" }
            ]
        };
    }

    /**
     * Return the tones your translation service supports (e.g. Formal, Informal).
     * Return an empty array if your service does not support tones.
     */
    tones(preferredLanguage?: string): TonesResponse {
        console.log(`Preferred language: ${preferredLanguage ?? "not specified"}`);

        // TODO: replace with your service's supported tones, or return { tones: [] }
        return {
            tones: [
                { value: "formal", label: "Formal" },
                { value: "informal", label: "Informal" }
            ]
        };
    }

    /**
     * Translate the items in the request from sourceLocale to targetLocale.
     * The result array must be the same length and order as request.items.
     */
    translate(request: TranslationRequest): TranslationResponse {
        // TODO: call your translation service here and return real translated strings.
        // The mock below echoes the inputs with locale/tone metadata so you can verify routing.
        const toneTag = request.tone ? ` [${request.tone}]` : "";
        return {
            result: request.items.map(
                item => `[${request.sourceLocale} → ${request.targetLocale}]${toneTag} ${item}`
            )
        };
    }

    /**
     * Return a 200 response when your service is available.
     * Optionally include an errorCode/errorMessage when degraded.
     */
    health(): HealthResponse {
        return { message: "OK" };
    }

    /**
     * Receive and log feedback submitted by the user in Adobe Express.
     * You can forward this to your analytics or quality pipeline.
     */
    feedback(request: FeedbackRequest): FeedbackResponse {
        console.log(`Feedback: type=${request.type}, reason=${request.reason}${request.note ? `, note="${request.note}"` : ""}`);
        return {};
    }
}

const app = express();
app.use(express.json());

const connector = new MyTranslateConnector();

app.get("/locales", (req, res) => {
    const preferredLanguage = req.query.preferredLanguage as string | undefined;
    res.json(connector.locales(preferredLanguage));
});

app.get("/tones", (req, res) => {
    const preferredLanguage = req.query.preferredLanguage as string | undefined;
    res.json(connector.tones(preferredLanguage));
});

app.post("/translate", (req, res) => {
    const body = req.body as TranslationRequest | undefined;
    if (!body) {
        res.status(400).json({ error: "Invalid request body" });
        return;
    }
    res.json(connector.translate(body));
});

app.get("/health", (_req, res) => {
    res.json(connector.health());
});

app.post("/feedback", (req, res) => {
    const body = req.body as FeedbackRequest | undefined;
    if (!body) {
        res.status(400).json({ error: "Invalid request body" });
        return;
    }
    res.json(connector.feedback(body));
});

const PORT = process.env.PORT ?? 3000;
app.listen(PORT, () => console.log(`Translate connector listening on port ${PORT}`));
